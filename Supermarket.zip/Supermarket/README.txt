Notes:

1) time permitting a comprehensive test suite would have been done
2) The code  currently would not be ready for 'production' as it does not cater for 'concurrent' requests and requires greater exception handling... defensive code needs to added into place
3) Refactoring needs to be considered also to provide 'flexibity' for example when adding more products (items)